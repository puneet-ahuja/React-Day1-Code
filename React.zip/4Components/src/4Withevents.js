import React from "react";


class MyClickableButton extends React.Component{

    onButtonClick(){
        console.log("Button clicked");
    }
    render(){
        return <input type="button" onClick={this.onButtonClick} value={this.props.MyText}></input>
    }
}

export default MyClickableButton;