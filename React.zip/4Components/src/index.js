import React from "react";
import ReactDOM from "react-dom"
import Divy from "./1App.js"
import MyButton from "./2ComponentWithProps.js"
import MyClassButton from "./3ClassSyntax.js"
import MyClickableButton from "./4Withevents.js"
import MyDiv from "./5PassData.js"
import ButtonWithDefaultProps from "./6DefaultProps.js"
import DivSetStateFromConstructor from "./7SetStateFromconstructor.js"
import Data from "./8WithValidations.js"
//import DivParentForButtonLifeCycle from "./9StateManagement.js"
import DivParentForButtonLifeCycle from "./11ComponentLifeCycle.js"
import TextBoxCustom from "./10TextBoxComponent"
import Page from "./12StateLessFunctions.js"

import CustomFormWithRefs from "./13FindDomElementsUsingRefs.js"

function onButtonClick(){
        console.log("Button clicked from parent component");
    }


ReactDOM.render(


  <div>Hello! <Divy>
    </Divy>
    {/* <MyButton MyText="Click Me!!!"></MyButton>
     <MyButton MyText="Click Me Twice!!!"></MyButton>
     <MyClassButton MyText="Click Me Twice!!!"></MyClassButton>
     <MyClickableButton MyText="Click Me Twice!!!"></MyClickableButton>
     <MyDiv></MyDiv>
     <ButtonWithDefaultProps/>
     <DivSetStateFromConstructor/>
     <Data/> 
     <DivParentForButtonLifeCycle/>
     <TextBoxCustom MyText="Hello"></TextBoxCustom>

     <Page ></Page> 
     <CustomFormWithRefs/>*/}
<Page/>
    </div> ,
 
  document.getElementById('root')
);

// setTimeout(() => {
//    ReactDOM.unmountComponentAtNode(document.getElementById('root'));}, 3000);