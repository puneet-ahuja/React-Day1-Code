import React from "react"

class ButtonComponentWithLifeCycle extends React.Component {

    render() {
        return <input type="button" onClick={this.props.onButtonClick} value={this.props.MyText}></input>
    }
}

class DivParentForButtonLifeCycle extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            MyText: "DivParentForButtonLifeCycle"//Comment this
        }
        this.onButtonClick = this.onButtonClick.bind(this)
    }
    getInitialState() {
         console.log("getInitialState clicked");
        return {            
            MyText: "DivParentForButtonLifeCycle"
        };
    }
    onButtonClick() {
        this.setState({ MyText: "Changing State" })
        console.log("Button clicked");
    }
    render() {
        return <div>
            <ButtonComponentWithLifeCycle onButtonClick={this.onButtonClick} MyText={this.state.MyText} ></ButtonComponentWithLifeCycle>
        </div>
    }
}

export default DivParentForButtonLifeCycle;