import React from "react";


class ButtonWithDefaultProps extends React.Component{

    onButtonClick(){
        console.log("Button clicked");
    }
    render(){
        return <input type="button" onClick={this.onButtonClick} value={this.props.MyText}></input>
    }
}

ButtonWithDefaultProps.defaultProps = {
   MyText: "Default From Component"
}
export default ButtonWithDefaultProps;