import React from "react";


class MyClickableButtonEventFromOutside extends React.Component{

    // onButtonClick(){
    //     console.log("Button clicked");
    // }
    render(){
        return <input type="button" onClick={this.props.onButtonClick} value={this.props.MyText}></input>
    }
}

class MyDiv extends React.Component{

    onButtonClick(){
        console.log("Button clicked");
    }
    render(){
        return <div> 
            <MyClickableButtonEventFromOutside onButtonClick={this.onButtonClick} MyText="Click Me"></MyClickableButtonEventFromOutside>
            </div>
    }
}


export default MyDiv;