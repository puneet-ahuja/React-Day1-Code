import React from "react";

class Divy extends React.Component{
    render(){
        return <div>Hello World From Component</div>;
    }
}

export default Divy;