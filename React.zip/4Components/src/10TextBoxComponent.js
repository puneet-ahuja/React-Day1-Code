import React from "react"

class TextBoxCustom extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            MyText: "Hello"
        }
        this.handleChange = this.handleChange.bind(this);
    }

     shouldComponentUpdate(newProps, newState) {
      return false;
   }
    handleChange(evt) {
        this.setState({
            MyText: evt.target.value
        });
    }
    render() {
        return <input type="text" 
        onChange={this.handleChange} 
        value={this.state.MyText}></input>
    }
}
export default TextBoxCustom;