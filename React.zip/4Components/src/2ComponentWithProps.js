import React from "react";


class MyButton extends React.Component{
    render(){
        return <input type="button" value={this.props.MyText}></input>
    }
}

export default MyButton;