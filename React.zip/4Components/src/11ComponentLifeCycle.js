import React from "react"

class ButtonComponentWithLifeCycle extends React.Component {

    render(){
        return <input type="button" onClick={this.props.onButtonClick} value={this.props.MyText}></input>
    }

   componentWillMount() {
      console.log('ButtonComponent will mount called!')
   }

   componentDidMount() {
      console.log('ButtonComponent Did mount called!')
   }

   componentWillReceiveProps(newProps) {    
      console.log('ButtonComponent Receive Props called!')
   }

   shouldComponentUpdate(newProps, newState) {
      return true;
   }

   componentWillUpdate(nextProps, nextState) {
      console.log('ButtonComponent Will Update called!');
   }

   componentDidUpdate(prevProps, prevState) {
      console.log('ButtonComponent Did Update called!')
   }

   componentWillUnmount() {
      console.log('ButtonComponent Will Unmount called!')
   }  
}

class DivParentForButtonLifeCycle extends React.Component{
   constructor(props){
        super(props);
        this.state = {
         MyText:"DivParentForButtonLifeCycle"
      }   
        this.onButtonClick = this.onButtonClick.bind(this)
    }
    onButtonClick(){
         this.setState({MyText: "Changing State"})
        console.log("Button clicked");
    }
    render(){
        return <div> 
            <ButtonComponentWithLifeCycle onButtonClick={this.onButtonClick} MyText={this.state.MyText} ></ButtonComponentWithLifeCycle>
            </div>
    }
}

export default DivParentForButtonLifeCycle;