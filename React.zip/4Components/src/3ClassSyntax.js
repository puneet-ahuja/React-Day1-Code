import React from "react";


const MyClassButton = React.createClass({
    render(){
        return <input type="button" value={this.props.MyText}></input>
    }
});

export default MyClassButton;