import React from "react";

class MyButton extends React.Component{ 
    render(){
        return <input type="button" onClick={this.props.onButtonClick} value={this.props.MyText}></input>
    }
}

class DivSetStateFromConstructor extends React.Component{
   constructor(){
        super();
       
        this.MyText ="Set from constructor";
       
    }
    onButtonClick(){
        console.log("Button clicked");
    }
    render(){
        return <div> 
            <MyButton onButtonClick={this.onButtonClick} MyText={this.MyText} ></MyButton>
            </div>
    }
}


export default DivSetStateFromConstructor;